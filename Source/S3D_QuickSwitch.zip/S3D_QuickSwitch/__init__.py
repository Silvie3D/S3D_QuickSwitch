import bpy
from bpy.props import BoolProperty, EnumProperty, CollectionProperty, IntProperty
from bpy.types import UIList, PropertyGroup, AddonPreferences, Operator

# Defines available tab types for switching
def tab_items():
    return [
        ('EMPTY', "Empty", "", 'CANCEL', 0),
        ('NODE_EDITOR', "Shader Editor", "", 'NODE_MATERIAL', 1),
        ('SEQUENCE_EDITOR', "Video Sequencer", "", 'SEQUENCE', 2),
        ('CLIP_EDITOR', "Movie Clip Editor", "", 'TRACKER', 3),
        ('DOPESHEET_EDITOR', "Timeline", "", 'TIME', 4),
        ('GRAPH_EDITOR', "Graph Editor", "", 'GRAPH', 5),
        ('NLA_EDITOR', "NLA Editor", "", 'NLA', 6),
        ('OUTLINER', "Outliner", "", 'OUTLINER', 7),
        ('PROPERTIES', "Properties", "", 'PROPERTIES', 8),
        ('SPREADSHEET', "Spreadsheet", "", 'SPREADSHEET', 9),
        ('IMAGE_EDITOR', "Image Editor", "", 'IMAGE', 10),
        ('VIEW_3D', "3D Viewport", "", 'VIEW3D', 12),
        ('PREFERENCES', "Preferences", "", 'PREFERENCES', 13),
        ('CONSOLE', "Python Console", "", 'CONSOLE', 14),
        ('TEXT_EDITOR', "Text Editor", "", 'TEXT', 15),
    ]

# Defines properties for each switch item
class TabSwitchItem(PropertyGroup):
    active: BoolProperty(name="Active", default=True)
    reverse: BoolProperty(name="Two-way", description="Switches both ways (Disable for one-way switching)",default=True)
    from_type: EnumProperty(        
        name="From Tab",
        description="The tab type to switch from",
        items=tab_items(),
        default='EMPTY'
    )
    to_type: EnumProperty(
        name="To Tab",
        description="The tab type to switch to",
        items=tab_items(),
        default="EMPTY"
    )

# UI list for displaying the tab switch settings
class TABSWITCH_UL_switch_list(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            row.prop(item, "active", text="")
            sub_row = row.row(align=True)
            sub_row.enabled = item.active
            sub_row.prop(item, "from_type", text="")
            sub_row.label(text="", icon='FORWARD')
            sub_row.prop(item, "to_type", text="")
            row.prop(item, "reverse", text="", icon='LOOP_BACK', toggle=True)
        elif self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'
            layout.label(text="", icon='ARROW_LEFTRIGHT')

# Preferences panel for configuring the tab switch options
class CustomAddonPreferences(AddonPreferences):
    bl_idname = __name__

    switches: CollectionProperty(type=TabSwitchItem)
    switch_index: IntProperty(name="Switch Index")

    def draw(self, context):
        layout = self.layout

        # Switch list UI
        row = layout.row()
        row.template_list("TABSWITCH_UL_switch_list", "", self, "switches", self, "switch_index")

        # Operations to add/remove/reorder switches
        col = row.column(align=True)
        col.operator("wm.add_switch", icon='ADD', text="")
        col.operator("wm.remove_switch", icon='REMOVE', text="").index = self.switch_index
        col.separator()
        col.operator("wm.move_switch", icon='TRIA_UP', text="").direction = 'UP'
        col.operator("wm.move_switch", icon='TRIA_DOWN', text="").direction = 'DOWN'

        # Help section
        box = layout.box()
        box.label(text="Help", icon='QUESTION')
        box.label(text="Add switches and configure them to quickly change between your desired editor types.")
        box.label(text="Use the loop icon to switch both ways.")

# Operator to add a new tab switch
class WM_OT_AddSwitch(Operator):
    bl_idname = "wm.add_switch"
    bl_label = "Add Switch"

    def execute(self, context):
        prefs = context.preferences.addons[__name__].preferences
        prefs.switches.add()
        return {'FINISHED'}

# Operator to remove a tab switch
class WM_OT_RemoveSwitch(Operator):
    bl_idname = "wm.remove_switch"
    bl_label = "Remove Switch"

    index: IntProperty()

    def execute(self, context):
        prefs = context.preferences.addons[__name__].preferences
        prefs.switches.remove(self.index)
        return {'FINISHED'}

# Operator to move a tab switch up or down in the list
class WM_OT_MoveSwitch(Operator):
    bl_idname = "wm.move_switch"
    bl_label = "Move Switch"
    bl_options = {'REGISTER', 'INTERNAL'}

    direction: EnumProperty(
        items=[('UP', "Up", ""), ('DOWN', "Down", "")],
        name="Direction",
        description="Direction to move the switch",
        default='UP'
    )

    def execute(self, context):
        prefs = context.preferences.addons[__name__].preferences
        index = prefs.switch_index

        if self.direction == 'UP' and index > 0:
            prefs.switches.move(index, index - 1)
            prefs.switch_index -= 1
        elif self.direction == 'DOWN' and index < len(prefs.switches) - 1:
            prefs.switches.move(index, index + 1)
            prefs.switch_index += 1

        return {'FINISHED'}

# Operator to switch tabs based on active switch configuration
class WM_OT_CustomTabSwitcher(Operator):
    bl_idname = "wm.custom_tab_switcher"
    bl_label = "Switch Custom Tab"
    bl_description = "S3D_Quickswitch"

    def execute(self, context):
        prefs = context.preferences.addons[__name__].preferences

        for switch in prefs.switches:
            if switch.active:
                current_area = context.area
                if current_area.type == switch.from_type:
                    current_area.type = switch.to_type
                    self.report({'INFO'}, f"Switched from {switch.from_type} to {switch.to_type}.")
                    return {'FINISHED'}
                elif switch.reverse and current_area.type == switch.to_type:
                    current_area.type = switch.from_type
                    self.report({'INFO'}, f"Switched from {switch.to_type} to {switch.from_type}.")
                    return {'FINISHED'}

        self.report({'WARNING'}, "No active switch found for the current tab.")
        return {'CANCELLED'}

# Draws the tab switch button in the UI
def draw_tab_switcher_btn(self, context):
    layout = self.layout
    prefs = context.preferences.addons[__name__].preferences
    for switch in prefs.switches:
        if switch.active:
            if context.area.type == switch.from_type:
                icon = next((item[3] for item in tab_items() if item[0] == switch.to_type), 'NONE')
                op = self.layout.operator("wm.custom_tab_switcher", text="", icon=icon)
                op.bl_description = f"Switch to {dict(tab_items())[switch.to_type]}"
                op.emboss = False
                self.layout.operator_context = 'INVOKE_DEFAULT'
                return
            elif switch.reverse and context.area.type == switch.to_type:
                icon = next((item[3] for item in tab_items() if item[0] == switch.from_type), 'NONE')
                op = self.layout.operator("wm.custom_tab_switcher", text="", icon=icon)
                op.bl_description = f"Switch to {dict(tab_items())[switch.from_type]}"
                op.emboss = False
                self.layout.operator_context = 'INVOKE_DEFAULT'
                return

# Register classes and append the tab switcher button to headers
def register():
    bpy.utils.register_class(TabSwitchItem)
    bpy.utils.register_class(TABSWITCH_UL_switch_list)
    bpy.utils.register_class(CustomAddonPreferences)
    bpy.utils.register_class(WM_OT_AddSwitch)
    bpy.utils.register_class(WM_OT_RemoveSwitch)
    bpy.utils.register_class(WM_OT_MoveSwitch)
    bpy.utils.register_class(WM_OT_CustomTabSwitcher)

    for header in [
        bpy.types.NODE_HT_header, bpy.types.DOPESHEET_HT_header, bpy.types.PROPERTIES_HT_header,
        bpy.types.OUTLINER_HT_header, bpy.types.SPREADSHEET_HT_header, bpy.types.IMAGE_HT_header,
        bpy.types.VIEW3D_HT_header, bpy.types.USERPREF_HT_header, bpy.types.CONSOLE_HT_header,
        bpy.types.TEXT_HT_header, bpy.types.GRAPH_HT_header, bpy.types.SEQUENCER_HT_header,
        bpy.types.CLIP_HT_header, bpy.types.NLA_HT_header, bpy.types.INFO_HT_header,
        bpy.types.TOPBAR_HT_upper_bar, bpy.types.STATUSBAR_HT_header
    ]:
        header.append(draw_tab_switcher_btn)

def unregister():
    bpy.utils.unregister_class(TabSwitchItem)
    bpy.utils.unregister_class(TABSWITCH_UL_switch_list)
    bpy.utils.unregister_class(CustomAddonPreferences)
    bpy.utils.unregister_class(WM_OT_AddSwitch)
    bpy.utils.unregister_class(WM_OT_RemoveSwitch)
    bpy.utils.unregister_class(WM_OT_MoveSwitch)
    bpy.utils.unregister_class(WM_OT_CustomTabSwitcher)

    for header in [
        bpy.types.NODE_HT_header, bpy.types.DOPESHEET_HT_header, bpy.types.PROPERTIES_HT_header,
        bpy.types.OUTLINER_HT_header, bpy.types.SPREADSHEET_HT_header, bpy.types.IMAGE_HT_header,
        bpy.types.VIEW3D_HT_header, bpy.types.USERPREF_HT_header, bpy.types.CONSOLE_HT_header,
        bpy.types.TEXT_HT_header, bpy.types.GRAPH_HT_header, bpy.types.SEQUENCER_HT_header,
        bpy.types.CLIP_HT_header, bpy.types.NLA_HT_header, bpy.types.INFO_HT_header,
        bpy.types.TOPBAR_HT_upper_bar, bpy.types.STATUSBAR_HT_header
    ]:
        header.remove(draw_tab_switcher_btn)

if __name__ == "__main__":
    register()
