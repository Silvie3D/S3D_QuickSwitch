import bpy
from bpy.props import CollectionProperty, StringProperty, EnumProperty, IntProperty
from bpy.types import PropertyGroup, Operator, UIList, AddonPreferences

# List of editor types
def tab_items():
    return [
        ('EMPTY', "Empty", "", 'CANCEL', 0),
        ('VIEW_3D', "3D Viewport", "", 'VIEW3D', 1),
        ('IMAGE_EDITOR', "Image Editor", "", 'IMAGE', 2),
        ('UV', "UV Editor", "", 'UV', 3),
        ('ShaderNodeTree', "Shader Editor", "", 'NODE_MATERIAL', 4),
        ('CompositorNodeTree', "Compositor", "", 'NODE_COMPOSITING', 5),
        ('TextureNodeTree', "Texture Node Editor", "", 'NODE_TEXTURE', 6),
        ('GeometryNodeTree', "Geometry Node Editor", "", 'NODETREE', 7),
        ('SEQUENCE_EDITOR', "Video Sequencer", "", 'SEQUENCE', 8),
        ('CLIP_EDITOR', "Movie Clip Editor", "", 'TRACKER', 9),
        ('DOPESHEET', "Dope Sheet", "", 'ACTION', 10),
        ('TIMELINE', "Timeline", "", 'TIME', 11),
        ('FCURVES', "Graph Editor", "", 'GRAPH', 12),
        ('DRIVERS', "Drivers", "", 'DRIVER', 13),
        ('NLA_EDITOR', "NLA Editor", "", 'NLA', 14),
        ('TEXT_EDITOR', "Text Editor", "", 'TEXT', 15),
        ('CONSOLE', "Python Console", "", 'CONSOLE', 16),
        ('INFO', "Info", "", 'INFO', 17),
        ('OUTLINER', "Outliner", "", 'OUTLINER', 18),
        ('PROPERTIES', "Properties", "", 'PROPERTIES', 19),
        ('SPREADSHEET', "Spreadsheet", "", 'SPREADSHEET', 20),
        ('PREFERENCES', "Preferences", "", 'PREFERENCES', 21),
    ]

# Property Groups
class EditorEntry(PropertyGroup):
    editor_type: EnumProperty(
        name="Editor Type",
        items=tab_items(),
        description="Type of editor",
    )

class EditorGroup(PropertyGroup):
    name: StringProperty(
        name="Group Name",
        description="Name of the editor group",
        default="Group"
    )
    editors: CollectionProperty(type=EditorEntry)
    active_editor_index: IntProperty()

# UI List for Groups
class EDITOR_UL_Groups(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        layout.prop(item, "name", text="", emboss=False)

# UI List for Editors
class EDITOR_UL_Entries(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        
        # Display dropdown
        row.prop(item, "editor_type", text="", icon_only=True, emboss=True)
        
        # Retrieve the name of the enum item
        editor_name = item.bl_rna.properties['editor_type'].enum_items[item.editor_type].name
        
        # Display the editor name as a non-interactive label
        row.label(text=editor_name)

# Operators that handle the re ordering in EDITOR_UL_Entries
class OT_MoveEditorUp(Operator):
    """Move selected editor up in the list"""
    bl_idname = "scene.move_editor_up"
    bl_label = "Move Up"

    def execute(self, context):
        scene = context.scene
        group = scene.editor_groups[scene.active_group_index]
        index = group.active_editor_index

        if index > 0:
            group.editors.move(index, index - 1)
            group.active_editor_index -= 1

            # Force a UI redraw for all areas
            for area in context.screen.areas:
                area.tag_redraw()

        return {'FINISHED'}

class OT_MoveEditorDown(Operator):
    """Move selected editor down in the list"""
    bl_idname = "scene.move_editor_down"
    bl_label = "Move Down"

    def execute(self, context):
        scene = context.scene
        group = scene.editor_groups[scene.active_group_index]
        index = group.active_editor_index

        if index < len(group.editors) - 1:
            group.editors.move(index, index + 1)
            group.active_editor_index += 1

            # Force a UI redraw for all areas
            for area in context.screen.areas:
                area.tag_redraw()

        return {'FINISHED'}

# Core Operators
class OT_AddEditorGroup(Operator):
    bl_idname = "scene.add_editor_group"
    bl_label = "Add Editor Group"

    def execute(self, context):
        scene = context.scene
        new_group = scene.editor_groups.add()
        new_group.name = f"Group {len(scene.editor_groups)}"
        scene.active_group_index = len(scene.editor_groups) - 1
        return {'FINISHED'}

class OT_RemoveEditorGroup(Operator):
    bl_idname = "scene.remove_editor_group"
    bl_label = "Remove Editor Group"

    def execute(self, context):
        scene = context.scene
        scene.editor_groups.remove(scene.active_group_index)
        scene.active_group_index = max(0, scene.active_group_index - 1)
        return {'FINISHED'}

class OT_AddEditorToGroup(Operator):
    bl_idname = "scene.add_editor_to_group"
    bl_label = "Add Editor to Group"

    def execute(self, context):
        scene = context.scene
        group = scene.editor_groups[scene.active_group_index]
        group.editors.add()
        return {'FINISHED'}

class OT_RemoveEditorFromGroup(Operator):
    bl_idname = "scene.remove_editor_from_group"
    bl_label = "Remove Editor from Group"

    def execute(self, context):
        scene = context.scene
        group = scene.editor_groups[scene.active_group_index]
        group.editors.remove(group.active_editor_index)
        group.active_editor_index = max(0, group.active_editor_index - 1)
        return {'FINISHED'}

class OT_SwitchEditor(Operator):
    bl_idname = "wm.switch_editor"
    bl_label = "Switch Editor"

    editor_type: StringProperty()

    def execute(self, context):
        context.area.ui_type = self.editor_type
        return {'FINISHED'}

# Preferences Panel
class QuickSwitchPreferences(AddonPreferences):
    bl_idname = __package__

    show_separator: bpy.props.BoolProperty(
        name="Separator",
        description="Enable or disable the visual separator between the editor switches and other header operators",
        default=True,
    )

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        # Split the layout into two columns for the lists
        split = layout.split(factor=0.5)

        # Group List
        col = split.column()
        col.label(text="Editor Groups")

        row = col.row()
        row.template_list(
            "EDITOR_UL_Groups", "", 
            scene, "editor_groups", 
            scene, "active_group_index",
            rows=7
        )

        row = col.row(align=True)
        row.operator("scene.add_editor_group", text="Add", icon="ADD")
        row.operator("scene.remove_editor_group", text="Remove", icon="REMOVE")

        # Add the separator toggle
        row.separator_spacer()
        row.prop(self, "show_separator")

        # Switch List
        col = split.column()
        col.label(text="Editor Switches")

        if scene.editor_groups:
            group = scene.editor_groups[scene.active_group_index]
            
            row = col.row()
            row.template_list(
                "EDITOR_UL_Entries", "", 
                group, "editors", 
                group, "active_editor_index",
                rows=7
            )

            row = col.row(align=True)
            row.operator("scene.add_editor_to_group", text="Add", icon="ADD")
            row.operator("scene.remove_editor_from_group", text="Remove", icon="REMOVE")
            
            # Add move up/down button
            row.separator_spacer()
            row.operator("scene.move_editor_up", text="Up", icon="TRIA_UP")
            row.operator("scene.move_editor_down", text="Down", icon="TRIA_DOWN")

# Draw UI Switches in Headers 
def draw_tab_switcher_btn(self, context):
    layout = self.layout
    scene = context.scene
    header_has_switches = False

    for group in scene.editor_groups:
        for editor in group.editors:
            if context.area.ui_type == editor.editor_type:
                header_has_switches = True
                break

    if header_has_switches:
        row = layout.row(align=True)

        # Special Case for Console, Info, Spreadsheet (Fix Alignment)
        if context.area.ui_type in {'CONSOLE', 'INFO', 'SPREADSHEET'}:
            row.separator_spacer()

        # Enable / Disable Separator
        preferences = context.preferences.addons[__package__].preferences
        if preferences.show_separator:
            row.label(text="||")  # Visual separator only when needed

        # Switches
        box = row.box() 
        switch_row = box.row(align=True)
        for group in scene.editor_groups:
            for editor in group.editors:
                if context.area.ui_type == editor.editor_type:
                    for e in group.editors:
                        icon = next((item[3] for item in tab_items() if item[0] == e.editor_type), 'NONE')
                        is_active = context.area.ui_type == e.editor_type
                        op = switch_row.operator("wm.switch_editor", text="", icon=icon, depress=is_active)
                        op.editor_type = e.editor_type
                    return

# Class List
classes = [
    EditorEntry,
    EditorGroup,
    OT_MoveEditorUp,
    OT_MoveEditorDown,
    QuickSwitchPreferences,
    EDITOR_UL_Groups,
    EDITOR_UL_Entries,
    OT_AddEditorGroup,
    OT_RemoveEditorGroup,
    OT_AddEditorToGroup,
    OT_RemoveEditorFromGroup,
    OT_SwitchEditor,
]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.editor_groups = CollectionProperty(type=EditorGroup)
    bpy.types.Scene.active_group_index = IntProperty()

    # Append UI buttons
    for header in [
        bpy.types.NODE_HT_header, bpy.types.DOPESHEET_HT_header, bpy.types.PROPERTIES_HT_header,
        bpy.types.OUTLINER_HT_header, bpy.types.SPREADSHEET_HT_header, bpy.types.IMAGE_HT_header,
        bpy.types.VIEW3D_HT_header, bpy.types.USERPREF_HT_header, bpy.types.CONSOLE_HT_header,
        bpy.types.TEXT_HT_header, bpy.types.GRAPH_HT_header, bpy.types.SEQUENCER_HT_header,
        bpy.types.CLIP_HT_header, bpy.types.NLA_HT_header, bpy.types.INFO_HT_header,
    ]:
        header.append(draw_tab_switcher_btn)

def unregister():
    for header in [
        bpy.types.NODE_HT_header, bpy.types.DOPESHEET_HT_header, bpy.types.PROPERTIES_HT_header,
        bpy.types.OUTLINER_HT_header, bpy.types.SPREADSHEET_HT_header, bpy.types.IMAGE_HT_header,
        bpy.types.VIEW3D_HT_header, bpy.types.USERPREF_HT_header, bpy.types.CONSOLE_HT_header,
        bpy.types.TEXT_HT_header, bpy.types.GRAPH_HT_header, bpy.types.SEQUENCER_HT_header,
        bpy.types.CLIP_HT_header, bpy.types.NLA_HT_header, bpy.types.INFO_HT_header,
    ]:
        header.remove(draw_tab_switcher_btn)

    del bpy.types.Scene.editor_groups
    del bpy.types.Scene.active_group_index

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __package__ == "__main__":
    register()
