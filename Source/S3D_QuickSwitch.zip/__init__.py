import bpy
from bpy.props import BoolProperty, EnumProperty, CollectionProperty, IntProperty
from bpy.types import UIList, PropertyGroup, AddonPreferences, Operator

# Updated list of editor types using ui_type strings
def tab_items():
    return [
        ('EMPTY', "Empty", "", 'CANCEL', 0),
        ('VIEW_3D', "3D Viewport", "", 'VIEW3D', 1),
        ('IMAGE_EDITOR', "Image Editor", "", 'IMAGE', 2),
        ('UV', "UV Editor", "", 'UV', 3),
        ('ShaderNodeTree', "Shader Editor", "", 'NODE_MATERIAL', 4),
        ('CompositorNodeTree', "Compositor", "", 'NODE_COMPOSITING', 5),
        ('TextureNodeTree', "Texture Node Editor", "", 'NODE_TEXTURE', 6),
        ('GeometryNodeTree', "Geometry Node Editor", "", 'NODETREE', 7),
        ('SEQUENCE_EDITOR', "Video Sequencer", "", 'SEQUENCE', 8),
        ('CLIP_EDITOR', "Movie Clip Editor", "", 'TRACKER', 9),
        ('DOPESHEET', "Dope Sheet", "", 'ACTION', 10),
        ('TIMELINE', "Timeline", "", 'TIME', 11),
        ('FCURVES', "Graph Editor", "", 'GRAPH', 12),
        ('DRIVERS', "Drivers", "", 'DRIVER', 13),
        ('NLA_EDITOR', "NLA Editor", "", 'NLA', 14),
        ('TEXT_EDITOR', "Text Editor", "", 'TEXT', 15),
        ('CONSOLE', "Python Console", "", 'CONSOLE', 16),
        ('INFO', "Info", "", 'INFO', 17),
        ('OUTLINER', "Outliner", "", 'OUTLINER', 18),
        ('PROPERTIES', "Properties", "", 'PROPERTIES', 19),
        ('SPREADSHEET', "Spreadsheet", "", 'SPREADSHEET', 20),
        ('PREFERENCES', "Preferences", "", 'PREFERENCES', 21),
    ]

def get_tab_name(tab_type):
    for item in tab_items():
        if item[0] == tab_type:
            return item[1]
    return tab_type

class TabSwitchItem(PropertyGroup):
    active: BoolProperty(name="Active", default=True)
    reverse: BoolProperty(name="Two-way", default=True)
    from_type: EnumProperty(name="From Tab", items=tab_items(), default='EMPTY')
    to_type: EnumProperty(name="To Tab", items=tab_items(), default="EMPTY")

class TABSWITCH_UL_switch_list(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        row = layout.row(align=True)
        row.prop(item, "active", text="")
        sub_row = row.row(align=True)
        sub_row.enabled = item.active
        sub_row.prop(item, "from_type", text="")
        sub_row.label(text="", icon='FORWARD')
        sub_row.prop(item, "to_type", text="")
        row.prop(item, "reverse", text="", icon='LOOP_BACK', toggle=True)

class CustomAddonPreferences(AddonPreferences):
    bl_idname = __package__
    switches: CollectionProperty(type=TabSwitchItem)
    switch_index: IntProperty(name="Switch Index")

    def draw(self, context):
        layout = self.layout
        row = layout.row()
        row.template_list("TABSWITCH_UL_switch_list", "", self, "switches", self, "switch_index")
        col = row.column(align=True)
        col.operator("wm.add_switch", icon='ADD', text="")
        col.operator("wm.remove_switch", icon='REMOVE', text="").index = self.switch_index
        col.separator()
        col.operator("wm.move_switch", icon='TRIA_UP', text="").direction = 'UP'
        col.operator("wm.move_switch", icon='TRIA_DOWN', text="").direction = 'DOWN'
        box = layout.box()
        box.label(text="Help", icon='QUESTION')
        box.label(text="Add switches and configure them to quickly change between your desired editor types.")
        box.label(text="Use the loop icon to switch both ways.")

class WM_OT_AddSwitch(Operator):
    bl_idname = "wm.add_switch"
    bl_label = "Add Switch"

    def execute(self, context):
        prefs = context.preferences.addons[__package__].preferences
        prefs.switches.add()
        return {'FINISHED'}

class WM_OT_RemoveSwitch(Operator):
    bl_idname = "wm.remove_switch"
    bl_label = "Remove Switch"
    index: IntProperty()

    def execute(self, context):
        prefs = context.preferences.addons[__package__].preferences
        prefs.switches.remove(self.index)
        return {'FINISHED'}

class WM_OT_MoveSwitch(Operator):
    bl_idname = "wm.move_switch"
    bl_label = "Move Switch"
    bl_options = {'REGISTER', 'INTERNAL'}
    direction: EnumProperty(items=[('UP', "Up", ""), ('DOWN', "Down", "")], default='UP')

    def execute(self, context):
        prefs = context.preferences.addons[__package__].preferences
        index = prefs.switch_index
        if self.direction == 'UP' and index > 0:
            prefs.switches.move(index, index - 1)
            prefs.switch_index -= 1
        elif self.direction == 'DOWN' and index < len(prefs.switches) - 1:
            prefs.switches.move(index, index + 1)
            prefs.switch_index += 1
        return {'FINISHED'}

class WM_OT_CustomTabSwitcher(Operator):
    bl_idname = "wm.custom_tab_switcher"
    bl_label = "Switch Custom Tab"
    bl_description = "S3D QuickSwitch"

    def execute(self, context):
        prefs = context.preferences.addons[__package__].preferences
        for switch in prefs.switches:
            if switch.active:
                current_area = context.area
                if current_area.ui_type == switch.from_type:
                    current_area.ui_type = switch.to_type
                    return {'FINISHED'}
                elif switch.reverse and current_area.ui_type == switch.to_type:
                    current_area.ui_type = switch.from_type
                    return {'FINISHED'}
        return {'CANCELLED'}

def draw_tab_switcher_btn(self, context):
    layout = self.layout
    prefs = context.preferences.addons[__package__].preferences
    
    # Dynamically add a spacer for specific editors that require alignment fixes
    if context.area.ui_type in {'CONSOLE', 'INFO', 'SPREADSHEET'}:
        layout.separator_spacer()  # Add spacer for problematic editors

    for switch in prefs.switches:
        if switch.active:
            if context.area.ui_type == switch.from_type:
                icon = next((item[3] for item in tab_items() if item[0] == switch.to_type), 'NONE')
                layout.operator("wm.custom_tab_switcher", text="", icon=icon)
                return
            elif switch.reverse and context.area.ui_type == switch.to_type:
                icon = next((item[3] for item in tab_items() if item[0] == switch.from_type), 'NONE')
                layout.operator("wm.custom_tab_switcher", text="", icon=icon)
                return


def register():
    bpy.utils.register_class(TabSwitchItem)
    bpy.utils.register_class(TABSWITCH_UL_switch_list)
    bpy.utils.register_class(CustomAddonPreferences)
    bpy.utils.register_class(WM_OT_AddSwitch)
    bpy.utils.register_class(WM_OT_RemoveSwitch)
    bpy.utils.register_class(WM_OT_MoveSwitch)
    bpy.utils.register_class(WM_OT_CustomTabSwitcher)

    for header in [
        bpy.types.NODE_HT_header, bpy.types.DOPESHEET_HT_header, bpy.types.PROPERTIES_HT_header,
        bpy.types.OUTLINER_HT_header, bpy.types.SPREADSHEET_HT_header, bpy.types.IMAGE_HT_header,
        bpy.types.VIEW3D_HT_header, bpy.types.USERPREF_HT_header, bpy.types.CONSOLE_HT_header,
        bpy.types.TEXT_HT_header, bpy.types.GRAPH_HT_header, bpy.types.SEQUENCER_HT_header,
        bpy.types.CLIP_HT_header, bpy.types.NLA_HT_header, bpy.types.INFO_HT_header,
        bpy.types.TOPBAR_HT_upper_bar, bpy.types.STATUSBAR_HT_header
    ]:
        header.append(draw_tab_switcher_btn)

def unregister():
    bpy.utils.unregister_class(TabSwitchItem)
    bpy.utils.unregister_class(TABSWITCH_UL_switch_list)
    bpy.utils.unregister_class(CustomAddonPreferences)
    bpy.utils.unregister_class(WM_OT_AddSwitch)
    bpy.utils.unregister_class(WM_OT_RemoveSwitch)
    bpy.utils.unregister_class(WM_OT_MoveSwitch)
    bpy.utils.unregister_class(WM_OT_CustomTabSwitcher)

    for header in [
        bpy.types.NODE_HT_header, bpy.types.DOPESHEET_HT_header, bpy.types.PROPERTIES_HT_header,
        bpy.types.OUTLINER_HT_header, bpy.types.SPREADSHEET_HT_header, bpy.types.IMAGE_HT_header,
        bpy.types.VIEW3D_HT_header, bpy.types.USERPREF_HT_header, bpy.types.CONSOLE_HT_header,
        bpy.types.TEXT_HT_header, bpy.types.GRAPH_HT_header, bpy.types.SEQUENCER_HT_header,
        bpy.types.CLIP_HT_header, bpy.types.NLA_HT_header, bpy.types.INFO_HT_header,
        bpy.types.TOPBAR_HT_upper_bar, bpy.types.STATUSBAR_HT_header
    ]:
        header.remove(draw_tab_switcher_btn)

if __package__ == "__main__":
    register()
