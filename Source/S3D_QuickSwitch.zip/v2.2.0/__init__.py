import bpy
from bpy.props import CollectionProperty, StringProperty, EnumProperty, IntProperty
from bpy.types import PropertyGroup, Operator, UIList, AddonPreferences
import json
import os
from datetime import datetime
from bpy_extras.io_utils import ExportHelper, ImportHelper


# Format: (EnumID, Name, Description, Icon, AreaType, UIType, KeymapName)
# Format: Key: {'name', 'icon', 'type', 'ui_type', 'keymap', 'settings'}
EDITOR_DATA = {
    'EMPTY': {'name': "Empty", 'icon': 'CANCEL', 'type': 'EMPTY', 'ui_type': None, 'keymap': None},
    'VIEW_3D': {'name': "3D Viewport", 'icon': 'VIEW3D', 'type': 'VIEW_3D', 'ui_type': None, 'keymap': "3D View"},
    'IMAGE_EDITOR': {'name': "Image Editor", 'icon': 'IMAGE', 'type': 'IMAGE_EDITOR', 'ui_type': None, 'keymap': "Image", 'exclude_ui_type': 'UV'},
    'UV': {'name': "UV Editor", 'icon': 'UV', 'type': 'IMAGE_EDITOR', 'ui_type': 'UV', 'keymap': None},
    'ShaderNodeTree': {'name': "Shader Editor", 'icon': 'NODE_MATERIAL', 'type': 'NODE_EDITOR', 'ui_type': 'ShaderNodeTree', 'keymap': "Node Editor"},
    'CompositorNodeTree': {'name': "Compositor", 'icon': 'NODE_COMPOSITING', 'type': 'NODE_EDITOR', 'ui_type': 'CompositorNodeTree', 'keymap': None},
    'TextureNodeTree': {'name': "Texture Node Editor", 'icon': 'NODE_TEXTURE', 'type': 'NODE_EDITOR', 'ui_type': 'TextureNodeTree', 'keymap': None},
    'GeometryNodeTree': {'name': "Geometry Node Editor", 'icon': 'NODETREE', 'type': 'NODE_EDITOR', 'ui_type': 'GeometryNodeTree', 'keymap': None},
    'SEQUENCE_EDITOR': {'name': "Video Sequencer", 'icon': 'SEQUENCE', 'type': 'SEQUENCE_EDITOR', 'ui_type': None, 'keymap': "Sequencer"},
    'CLIP_EDITOR': {'name': "Movie Clip Editor", 'icon': 'TRACKER', 'type': 'CLIP_EDITOR', 'ui_type': None, 'keymap': "Clip Editor"},
    'DOPESHEET': {'name': "Dope Sheet", 'icon': 'ACTION', 'type': 'DOPESHEET_EDITOR', 'ui_type': None, 'keymap': "Dopesheet", 'exclude_ui_type': 'TIMELINE'},
    'TIMELINE': {'name': "Timeline", 'icon': 'TIME', 'type': 'DOPESHEET_EDITOR', 'ui_type': 'TIMELINE', 'keymap': "Dopesheet", 'settings': {'mode': 'TIMELINE'}},
    'FCURVES': {'name': "Graph Editor", 'icon': 'GRAPH', 'type': 'GRAPH_EDITOR', 'ui_type': 'FCURVES', 'keymap': "Graph Editor"},
    'DRIVERS': {'name': "Drivers", 'icon': 'DRIVER', 'type': 'GRAPH_EDITOR', 'ui_type': 'DRIVERS', 'keymap': None},
    'NLA_EDITOR': {'name': "NLA Editor", 'icon': 'NLA', 'type': 'NLA_EDITOR', 'ui_type': None, 'keymap': "NLA Editor"},
    'TEXT_EDITOR': {'name': "Text Editor", 'icon': 'TEXT', 'type': 'TEXT_EDITOR', 'ui_type': None, 'keymap': "Text"},
    'CONSOLE': {'name': "Python Console", 'icon': 'CONSOLE', 'type': 'CONSOLE', 'ui_type': None, 'keymap': "Console"},
    'INFO': {'name': "Info", 'icon': 'INFO', 'type': 'INFO', 'ui_type': None, 'keymap': "Info"},
    'OUTLINER': {'name': "Outliner", 'icon': 'OUTLINER', 'type': 'OUTLINER', 'ui_type': None, 'keymap': "Outliner"},
    'PROPERTIES': {'name': "Properties", 'icon': 'PROPERTIES', 'type': 'PROPERTIES', 'ui_type': None, 'keymap': "Properties"},
    'SPREADSHEET': {'name': "Spreadsheet", 'icon': 'SPREADSHEET', 'type': 'SPREADSHEET', 'ui_type': None, 'keymap': "Spreadsheet"},
    'PREFERENCES': {'name': "Preferences", 'icon': 'PREFERENCES', 'type': 'PREFERENCES', 'ui_type': None, 'keymap': "Preferences"},
    'FILES': {'name': "File Browser", 'icon': 'FILEBROWSER', 'type': 'FILE_BROWSER', 'ui_type': None, 'keymap': "File Browser", 'exclude_ui_type': 'ASSETS'},
    'ASSETS': {'name': "Asset Browser", 'icon': 'ASSET_MANAGER', 'type': 'FILE_BROWSER', 'ui_type': 'ASSETS', 'keymap': None},
}

# Legacy mappings for backward compatibility
LEGACY_MAPPINGS = {
    'FILE_BROWSER': 'FILES',
    'ASSET_BROWSER': 'ASSETS',
}

def tab_items():
    """Return all editor items"""
    items = []
    for i, (key, val) in enumerate(EDITOR_DATA.items()):
        items.append((key, val['name'], "", val['icon'], i))
    return items

def get_used_editors(context, current_entry=None):
    """Get a set of editor types already in use across all groups."""
    used = set()
    try:
        prefs = context.preferences.addons[__package__].preferences
        for group in prefs.editor_groups:
            for editor in group.editors:
                # Use the CACHED value to avoid triggering the dynamic enum callback again (infinite recursion)
                val = getattr(editor, 'editor_type_cache', 'EMPTY')
                if val != 'EMPTY':
                    # Skip the current entry being edited
                    if current_entry is not None and editor == current_entry:
                        continue
                    used.add(val)
    except Exception:
        pass
    return used

def get_available_editor_items(self, context):
    """Dynamic callback for editor_type EnumProperty"""
    items = []
    used_editors = get_used_editors(context, current_entry=self)
    current_type = getattr(self, 'editor_type_cache', 'EMPTY')
    
    for i, (key, val) in enumerate(EDITOR_DATA.items()):
        # Always include EMPTY option
        if key == 'EMPTY':
            items.append((key, val['name'], "", val['icon'], i))
        # Include the current selection so it stays visible
        elif key == current_type:
            items.append((key, val['name'], "", val['icon'], i))
        # Include only if not used by another switch
        elif key not in used_editors:
            items.append((key, val['name'], "", val['icon'], i))
    
    return items

def resolve_editor_data(editor_type):
    """Return the data dict for a given editor type, handling aliases."""
    if editor_type in LEGACY_MAPPINGS:
        editor_type = LEGACY_MAPPINGS[editor_type]
    return EDITOR_DATA.get(editor_type)

def get_config_path():
    """Get the path to the persistent config file"""
    extension_dir = bpy.utils.extension_path_user(__package__, path="", create=True)
    return os.path.join(extension_dir, 's3d_quickswitch_data.json')

def save_config_to_json(context=None):
    """Save current preferences to a JSON file."""
    try:
        if context:
            prefs = context.preferences.addons[__package__].preferences
        else:
            prefs = bpy.context.preferences.addons[__package__].preferences
            
        data = {
            'show_separator': prefs.show_separator,
            'switch_position': prefs.switch_position,
            'use_shortcuts': prefs.use_shortcuts,
            'cycle_shortcut_key': prefs.cycle_shortcut_key,
            'cycle_shortcut_modifier': prefs.cycle_shortcut_modifier,
            'editor_groups': []
        }
        
        for group in prefs.editor_groups:
            g_data = {
                'name': group.name,
                'show_in_header': group.show_in_header,
                'editors': []
            }
            for editor in group.editors:
                g_data['editors'].append({'editor_type': editor.editor_type})
            data['editor_groups'].append(g_data)
            
        with open(get_config_path(), 'w') as f:
            json.dump(data, f, indent=4)
            
    except Exception as e:
        print(f"S3D_QuickSwitch: Failed to save config: {e}")

def load_config_from_json(context=None):
    """Load preferences from JSON file"""
    path = get_config_path()
    if not os.path.exists(path):
        return

    try:
        if context:
            prefs = context.preferences.addons[__package__].preferences
        else:
            # Fallback function
            prefs = bpy.context.preferences.addons[__package__].preferences
            
        with open(path, 'r') as f:
            data = json.load(f)
            
        # UI Settings
        if 'show_separator' in data: prefs.show_separator = data['show_separator']
        if 'switch_position' in data: prefs.switch_position = data['switch_position']
        
        # Shortcuts
        if 'use_shortcuts' in data: prefs.use_shortcuts = data['use_shortcuts']
        if 'cycle_shortcut_key' in data: prefs.cycle_shortcut_key = data['cycle_shortcut_key']
        if 'cycle_shortcut_modifier' in data: prefs.cycle_shortcut_modifier = data['cycle_shortcut_modifier']
        
        # Groups
        if 'editor_groups' in data:
            prefs.editor_groups.clear()
            for g_data in data['editor_groups']:
                group = prefs.editor_groups.add()
                group.name = g_data.get('name', "Group")
                group.show_in_header = g_data.get('show_in_header', True)
                
                for e_data in g_data.get('editors', []):
                    editor = group.editors.add()
                    editor.editor_type = e_data.get('editor_type', 'EMPTY')
                    
    except Exception as e:
        print(f"S3D_QuickSwitch: Failed to load config: {e}")

def update_prefs_save(self, context):
    """Callback to force save preferences when settings change"""
    try:
        save_config_to_json(context)
    except Exception:
        pass

def is_area_matching_editor(area, editor_type):
    """Check if a Blender area matches the given editor token"""
    data = resolve_editor_data(editor_type)
    if not data:
        return False
    
    if not area or area.type != data['type']:
        return False
        
    # Check ui_type if specified
    if data['ui_type'] is not None:
        if getattr(area, 'ui_type', None) != data['ui_type']:
            return False

    # Check excluded ui_type if specified
    if 'exclude_ui_type' in data and data['exclude_ui_type']:
        current_ui_type = getattr(area, 'ui_type', None)
        exclusions = data['exclude_ui_type']
        if isinstance(exclusions, str):
            if current_ui_type == exclusions:
                return False
        elif isinstance(exclusions, (list, tuple)):
            if current_ui_type in exclusions:
                return False
            
    # Check settings if specified
    if 'settings' in data and data['settings']:
        active_space = area.spaces.active
        if not active_space:
            return False
        for prop, val in data['settings'].items():
            if getattr(active_space, prop, None) != val:
                return False
                
    return True

def enum_name_and_icon(editor_type):
    """Return display name and icon id"""
    data = resolve_editor_data(editor_type)
    if data:
        return data['name'], data['icon']
    return 'Unknown', 'NONE'

# Property Groups
def update_editor_type(self, context):
    """Add to Cache and save preference""" 
    self.editor_type_cache = self.editor_type
    update_prefs_save(self, context)

class EditorEntry(PropertyGroup):
    # Internal cache definition
    editor_type_cache: StringProperty(default='EMPTY', options={'HIDDEN'})
    
    editor_type: EnumProperty(
        name="Editor Type",
        items=get_available_editor_items,
        description="Type of editor to switch to when this entry is clicked. Each editor can only be assigned to one switch.",
        update=update_editor_type,
    )

class EditorGroup(PropertyGroup):
    name: StringProperty(
        name="Group Name",
        description="Name of this editor group - helps organize related editors together",
        default="Group",
        update=update_prefs_save,
    )
    editors: CollectionProperty(
        type=EditorEntry,
        description="Collection of editor switches in this group"
    )
    active_editor_index: IntProperty(
        description="Index of the currently selected editor in this group"
    )
    show_in_header: bpy.props.BoolProperty(
        name="Show in Header",
        description="Show this group's switches in the editor headers",
        default=True,
        update=update_prefs_save,
    )

class EDITOR_UL_Groups(UIList):
    """Editor groups"""
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        layout.prop(item, "name", text="", emboss=False)
        icon = 'HIDE_OFF' if item.show_in_header else 'HIDE_ON'
        layout.prop(item, "show_in_header", text="", icon=icon, emboss=False)

class EDITOR_UL_Entries(UIList):
    """Editors within a group"""
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        row.prop(item, "editor_type", text="", icon_only=True, emboss=True)
        editor_name, _ = enum_name_and_icon(item.editor_type)
        row.label(text=editor_name)

# Re-Ordering Operators
class OT_MoveEditorUp(Operator):
    """Move editor up"""
    bl_idname = "scene.move_editor_up"
    bl_label = "Move Up"
    bl_description = "Move the selected editor switch up in the list"

    def execute(self, context):
        preferences = context.preferences.addons[__package__].preferences
        if len(preferences.editor_groups) == 0:
            return {'CANCELLED'}
        group_index = min(max(0, preferences.active_group_index), len(preferences.editor_groups) - 1)
        group = preferences.editor_groups[group_index]
        if len(group.editors) == 0:
            return {'CANCELLED'}
        index = max(0, min(group.active_editor_index, len(group.editors) - 1))

        if index > 0:
            group.editors.move(index, index - 1)
            group.active_editor_index = index - 1

            # Force UI redraw for live feedback
            for area in context.screen.areas:
                area.tag_redraw()

        bpy.ops.wm.save_userpref()
        return {'FINISHED'}

class OT_MoveEditorDown(Operator):
    """Move editor down"""
    bl_idname = "scene.move_editor_down"
    bl_label = "Move Down"
    bl_description = "Move the selected editor switch down in the list"

    def execute(self, context):
        preferences = context.preferences.addons[__package__].preferences
        if len(preferences.editor_groups) == 0:
            return {'CANCELLED'}
        group_index = min(max(0, preferences.active_group_index), len(preferences.editor_groups) - 1)
        group = preferences.editor_groups[group_index]
        if len(group.editors) == 0:
            return {'CANCELLED'}
        index = max(0, min(group.active_editor_index, len(group.editors) - 1))

        if index < len(group.editors) - 1:
            group.editors.move(index, index + 1)
            group.active_editor_index = index + 1

            # Force UI redraw for live feedback
            for area in context.screen.areas:
                area.tag_redraw()

        bpy.ops.wm.save_userpref()
        return {'FINISHED'}

# Core Ops
class OT_AddEditorGroup(Operator):
    bl_idname = "scene.add_editor_group"
    bl_label = "Add Editor Group"
    bl_description = "Add a new group of editor switches"

    def execute(self, context):
        preferences = context.preferences.addons[__package__].preferences
        new_group = preferences.editor_groups.add()
        new_group.name = f"Group {len(preferences.editor_groups)}"
        preferences.active_group_index = len(preferences.editor_groups) - 1
        bpy.ops.wm.save_userpref()
        return {'FINISHED'}

class OT_RemoveEditorGroup(Operator):
    bl_idname = "scene.remove_editor_group"
    bl_label = "Remove Editor Group"
    bl_description = "Remove the selected editor group"

    def execute(self, context):
        preferences = context.preferences.addons[__package__].preferences
        preferences.editor_groups.remove(preferences.active_group_index)
        preferences.active_group_index = max(0, preferences.active_group_index - 1)
        bpy.ops.wm.save_userpref()
        return {'FINISHED'}

class OT_AddEditorToGroup(Operator):
    bl_idname = "scene.add_editor_to_group"
    bl_label = "Add Editor to Group"
    bl_description = "Add a new editor switch to the selected group"

    def execute(self, context):
        preferences = context.preferences.addons[__package__].preferences
        if len(preferences.editor_groups) == 0:
            return {'CANCELLED'}
        group_index = min(max(0, preferences.active_group_index), len(preferences.editor_groups) - 1)
        group = preferences.editor_groups[group_index]
        group.editors.add()
        bpy.ops.wm.save_userpref()
        return {'FINISHED'}

class OT_RemoveEditorFromGroup(Operator):
    bl_idname = "scene.remove_editor_from_group"
    bl_label = "Remove Editor from Group"
    bl_description = "Remove the selected editor switch from the group"

    def execute(self, context):
        preferences = context.preferences.addons[__package__].preferences
        if len(preferences.editor_groups) == 0:
            return {'CANCELLED'}
        group_index = min(max(0, preferences.active_group_index), len(preferences.editor_groups) - 1)
        group = preferences.editor_groups[group_index]
        if len(group.editors) == 0:
            return {'CANCELLED'}
        index = max(0, min(group.active_editor_index, len(group.editors) - 1))
        group.editors.remove(index)
        group.active_editor_index = max(0, index - 1)
        bpy.ops.wm.save_userpref()
        return {'FINISHED'}

class OT_SwitchEditor(Operator):
    bl_idname = "wm.switch_editor"
    bl_label = "Switch Editor"
    bl_description = "Switch to the selected editor type"

    editor_type: StringProperty(
        description="Type of editor to switch to"
    )

    @classmethod
    def description(cls, context, properties):
        name, _icon = enum_name_and_icon(getattr(properties, "editor_type", ""))
        return f"Switch to {name}"

    def execute(self, context):
        # Guard invalid target
        if self.editor_type == 'EMPTY':
            self.report({'ERROR'}, "Cannot switch to Empty editor type. Please select a valid editor in preferences.")
            return {'CANCELLED'}

        area = context.area
        if not area:
            self.report({'WARNING'}, "No active area to switch.")
            return {'CANCELLED'}

        data = resolve_editor_data(self.editor_type)
        if not data:
             self.report({'ERROR'}, f"Invalid editor type: {self.editor_type}")
             return {'CANCELLED'}

        try:
            area.type = data['type']
            
            if data['ui_type'] is not None:
                try:
                    area.ui_type = data['ui_type']
                except Exception:
                    pass
            
            # Apply settings
            if 'settings' in data and data['settings']:
                # Check active space again for changes
                active_space = area.spaces.active
                if active_space:
                    for prop, val in data['settings'].items():
                        try:
                            setattr(active_space, prop, val)
                        except Exception as e:
                            print(f"S3D_QuickSwitch: Failed to set property {prop} to {val}: {e}")
                            
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Switch failed: {e}")
            return {'CANCELLED'}

# Cycle through editors
class OT_CycleEditors(Operator):
    bl_idname = "wm.cycle_editors"
    bl_label = "Cycle Through Editors"
    bl_description = "Cycle to the next editor in the current editor group"
    
    def execute(self, context):
        area = context.area
        if not area:
            self.report({'WARNING'}, "No active area to cycle.")
            return {'CANCELLED'}

        preferences = context.preferences.addons[__package__].preferences

        # Determine active group
        active_group = None
        for group in preferences.editor_groups:
            for editor in group.editors:
                if editor.editor_type != 'EMPTY' and is_area_matching_editor(area, editor.editor_type):
                    active_group = group
                    break
            if active_group:
                break

        if not active_group:
            self.report({'WARNING'}, "Current editor is not in any group or group is empty")
            return {'CANCELLED'}

        editors_list = [e.editor_type for e in active_group.editors if e.editor_type != 'EMPTY']
        if not editors_list:
            self.report({'WARNING'}, "Active group has no editors to cycle")
            return {'CANCELLED'}

        # Find current index
        try:
            current_index = next(i for i, et in enumerate(editors_list) if is_area_matching_editor(area, et))
        except StopIteration:
            # Not found, start at first
            current_index = -1

        next_index = (current_index + 1) % len(editors_list)
        try:
            next_type = editors_list[next_index]
            data = resolve_editor_data(next_type)
            if not data:
                raise ValueError("Invalid editor data")

            area.type = data['type']
            if data['ui_type'] is not None:
                try:
                    area.ui_type = data['ui_type']
                except Exception:
                    pass
            
            # Apply settings
            if 'settings' in data and data['settings']:
                active_space = area.spaces.active
                if active_space:
                    for prop, val in data['settings'].items():
                        try:
                            setattr(active_space, prop, val)
                        except Exception:
                            pass
                            
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Error cycling editors: {str(e)}")
            return {'CANCELLED'}

# Export/Import Operators
class OT_ExportConfig(Operator, ExportHelper):
    bl_idname = "s3d.export_config"
    bl_label = "Export Settings"
    bl_description = "Export addon settings to a JSON file"
    filename_ext = ".json"

    filter_glob: StringProperty(
        default="*.json",
        options={'HIDDEN'},
        maxlen=255,
    )
    
    def invoke(self, context, event):
        # Set default filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.filepath = f"quickswitch_config_{timestamp}.json"
        return ExportHelper.invoke(self, context, event)

    def execute(self, context):
        try:
            save_config_to_json(context) # Updates internal file first
            
            # Copy internal file content to target
            target_path = self.filepath
            with open(get_config_path(), 'r') as src, open(target_path, 'w') as dst:
                dst.write(src.read())
                
            self.report({'INFO'}, f"Settings exported to {target_path}")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Export failed: {e}")
            return {'CANCELLED'}

class OT_ImportConfig(Operator, ImportHelper):
    bl_idname = "s3d.import_config"
    bl_label = "Import Settings"
    bl_description = "Import addon settings from a JSON file"
    filename_ext = ".json"

    filter_glob: StringProperty(
        default="*.json",
        options={'HIDDEN'},
        maxlen=255,
    )

    def execute(self, context):
        try:
            with open(self.filepath, 'r') as f:
                data = json.load(f)
                
            # Validate
            if 'editor_groups' not in data:
                self.report({'ERROR'}, "Invalid config file format")
                return {'CANCELLED'}
                
            # Apply to prefs
            prefs = context.preferences.addons[__package__].preferences
            
            # UI Settings
            if 'show_separator' in data: prefs.show_separator = data['show_separator']
            if 'switch_position' in data: prefs.switch_position = data['switch_position']
            
            # Shortcuts
            if 'use_shortcuts' in data: prefs.use_shortcuts = data['use_shortcuts']
            if 'cycle_shortcut_key' in data: prefs.cycle_shortcut_key = data['cycle_shortcut_key']
            if 'cycle_shortcut_modifier' in data: prefs.cycle_shortcut_modifier = data['cycle_shortcut_modifier']
            
            # Groups
            prefs.editor_groups.clear()
            for g_data in data['editor_groups']:
                group = prefs.editor_groups.add()
                group.name = g_data.get('name', "Group")
                group.show_in_header = g_data.get('show_in_header', True)
                
                for e_data in g_data.get('editors', []):
                    editor = group.editors.add()
                    editor.editor_type = e_data.get('editor_type', 'EMPTY')
            
            # Save to internal config
            save_config_to_json(context)
            
            # Update keymaps
            update_shortcuts(None, context)
            
            self.report({'INFO'}, "Settings imported successfully")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Import failed: {e}")
            return {'CANCELLED'}

# Callback functions
def update_shortcuts(self, context):
    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    register_shortcuts()
    save_config_to_json(context)



# Preferences Panel
class VIEW3D_PT_QuickSwitchPreferences(AddonPreferences):
    bl_idname = __package__

    show_separator: bpy.props.BoolProperty(
        name="Separator",
        description="Enable or disable the visual separator between the editor switches and other header operators",
        default=True,
        update=update_prefs_save,
    )
    
    switch_position: bpy.props.EnumProperty(
        name="Switch Position",
        description="Position switches on the left or right side of the header",
        items=[
            ('LEFT', "Left", "Position switches on the left side, after editor type dropdown"),
            ('RIGHT', "Right", "Position switches on the right side (default)"),
        ],
        default='LEFT',
        update=update_prefs_save,
    )
    
    # Shortcut key
    use_shortcuts: bpy.props.BoolProperty(
        name="Enable Keyboard Shortcuts",
        description="Enable keyboard shortcuts for cycling through editors",
        default=True,
        update=update_shortcuts
    )
    
    cycle_shortcut_key: bpy.props.EnumProperty(
        name="Key",
        description="Key to use for cycling through editors",
        items=[
            ('SPACE', "Space", "Use Space for editor cycling"),
            ('QUOTE', "Quote (')", "Use quote (') for editor cycling"),
            ('ACCENT_GRAVE', "Backtick (`)", "Use backtick (`) for editor cycling"),
            ('PERIOD', "Period (.)", "Use period (.) for editor cycling"),
            ('COMMA', "Comma (,)", "Use comma (,) for editor cycling"),
            ('A', "A", "Use A for editor cycling"),
            ('Q', "Q", "Use Q for editor cycling"),
            ('W', "W", "Use W for editor cycling"),
            ('E', "E", "Use E for editor cycling"),
            ('S', "S", "Use S for editor cycling"),
            ('D', "D", "Use D for editor cycling"),
            ('F', "F", "Use F for editor cycling"),
            ('X', "X", "Use X for editor cycling"),
            ('Z', "Z", "Use Z for editor cycling"),
        ],
        default='ACCENT_GRAVE',
        update=update_shortcuts
    )

    cycle_shortcut_modifier: bpy.props.EnumProperty(
        name="Modifier",
        description="Modifier key to combine with the selected key",
        items=[
            ('CTRL', "Ctrl", "Use Ctrl as the modifier key"),
            ('ALT', "Alt", "Use Alt as the modifier key"),
            ('SHIFT', "Shift", "Use Shift as the modifier key"),
            ('NONE', "None", "Don't use a modifier key"),
            ('CTRL_ALT', "Ctrl+Alt", "Use Ctrl+Alt as the modifier keys"),
            ('CTRL_SHIFT', "Ctrl+Shift", "Use Ctrl+Shift as the modifier keys"),
            ('ALT_SHIFT', "Alt+Shift", "Use Alt+Shift as the modifier keys"),
        ],
        default='ALT',
        update=update_shortcuts
    )

    # Add editor groups to preferences
    editor_groups: CollectionProperty(
        type=EditorGroup,
        description="List of all editor groups configured in this addon"
    )
    active_group_index: IntProperty(
        description="Index of the currently selected editor group"
    )

    def draw(self, context):
        layout = self.layout

        # Split layout to columns
        split = layout.split(factor=0.5)

        # Group List
        col = split.column()
        col.label(text="Editor Groups")

        row = col.row()
        row.template_list(
            "EDITOR_UL_Groups", "", 
            self, "editor_groups", 
            self, "active_group_index",
            rows=7
        )

        row = col.row(align=True)
        row.operator("scene.add_editor_group", text="Add", icon="ADD")
        row.operator("scene.remove_editor_group", text="Remove", icon="REMOVE")

        # Switch List
        col = split.column()
        col.label(text="Editor Switches")

        if self.editor_groups and len(self.editor_groups) > 0:
            group = self.editor_groups[self.active_group_index]
            
            row = col.row()
            row.template_list(
                "EDITOR_UL_Entries", "", 
                group, "editors", 
                group, "active_editor_index",
                rows=7
            )

            row = col.row(align=True)
            row.operator("scene.add_editor_to_group", text="Add", icon="ADD")
            row.operator("scene.remove_editor_from_group", text="Remove", icon="REMOVE")
            
            # Add move up/down button
            row.separator_spacer()
            row.operator("scene.move_editor_up", text="Up", icon="TRIA_UP")
            row.operator("scene.move_editor_down", text="Down", icon="TRIA_DOWN")

        box = layout.box()
        # Row split
        row = box.row()
        split = row.split(factor=0.5)
        
        # Left side
        left_col = split.column()
        left_row = left_col.row()
        left_row.label(text="Switch Position:")
        left_row.prop(self, "switch_position", expand=True)
        
        # Right side
        right_col = split.column()
        right_row = right_col.row(align=True)
        right_row.prop(self, "show_separator")
        right_row.separator()
        right_row.operator("s3d.export_config", text="Export", icon='EXPORT')
        right_row.operator("s3d.import_config", text="Import", icon='IMPORT')
        
        # Shortcut preferences
        box = layout.box()
        box.label(text="Keyboard Shortcuts", icon='KEYINGSET')
        
        row = box.row()
        row.prop(self, "use_shortcuts")
        
        # Only show key selection if shortcuts are enabled
        if self.use_shortcuts:
            row = box.row()
            row.label(text="Cycle Editors:")
            split = row.split(factor=0.5)
            split.prop(self, "cycle_shortcut_modifier", text="")
            split.prop(self, "cycle_shortcut_key", text="")
            row = box.row()
            modifier_text = ""
            if self.cycle_shortcut_modifier == 'CTRL':
                modifier_text = "Ctrl+"
            elif self.cycle_shortcut_modifier == 'ALT':
                modifier_text = "Alt+"
            elif self.cycle_shortcut_modifier == 'SHIFT':
                modifier_text = "Shift+"
            elif self.cycle_shortcut_modifier == 'CTRL_ALT':
                modifier_text = "Ctrl+Alt+"
            elif self.cycle_shortcut_modifier == 'CTRL_SHIFT':
                modifier_text = "Ctrl+Shift+"
            elif self.cycle_shortcut_modifier == 'ALT_SHIFT':
                modifier_text = "Alt+Shift+"
            
            # Get key name
            key_text = ""
            if self.cycle_shortcut_key == 'ACCENT_GRAVE':
                key_text = "Backtick (`)"
            elif self.cycle_shortcut_key == 'QUOTE':
                key_text = "Quote (')"
            elif self.cycle_shortcut_key == 'COMMA':
                key_text = "Comma (,)"
            elif self.cycle_shortcut_key == 'PERIOD':
                key_text = "Period (.)"
            else:
                key_text = self.cycle_shortcut_key
                
            row.label(text=f"Press {modifier_text}{key_text} to cycle through editors in a group")
            
            # Warning about possible conflicts
            if self.cycle_shortcut_key == 'TAB' and self.cycle_shortcut_modifier == 'CTRL':
                row = box.row()
                row.label(text="Warning: Ctrl+Tab conflicts with Blender's built-in shortcuts", icon='ERROR')

# Draw UI Switches
def draw_tab_switcher_btn(self, context):
    """Draw switches on the right side"""
    layout = self.layout
    preferences = context.preferences.addons[__package__].preferences

    if preferences.switch_position != 'RIGHT':
        return

    if len(preferences.editor_groups) == 0:
        return

    # Ensure current area -> configured group
    found_switches = False
    for group in preferences.editor_groups:
        if not group.show_in_header:
            continue
        for editor in group.editors:
            if editor.editor_type != 'EMPTY' and is_area_matching_editor(context.area, editor.editor_type):
                found_switches = True
                break
        if found_switches:
            break

    if not found_switches:
        return

    row = layout.row(align=True)

    # Push to far right for certain editors
    if context.area and context.area.type in {'CONSOLE', 'INFO', 'SPREADSHEET', 'ASSET_BROWSER', 'FILE_BROWSER'}:
        row.separator_spacer()

    # Visual separator as requested
    if preferences.show_separator:
        row.label(text="||")

    box = row.box()
    switch_row = box.row(align=True)

    # Draw switches for the first matching group
    for group in preferences.editor_groups:
        if not group.show_in_header:
            continue
        for editor in group.editors:
            if editor.editor_type != 'EMPTY' and is_area_matching_editor(context.area, editor.editor_type):
                for e in group.editors:
                    name, icon = enum_name_and_icon(e.editor_type)
                    is_active = is_area_matching_editor(context.area, e.editor_type)
                    op = switch_row.operator("wm.switch_editor", text="", icon=icon, depress=is_active)
                    op.editor_type = e.editor_type
                return

# Left side drawing function
def draw_left_switches(self, context):
    preferences = context.preferences.addons[__package__].preferences
    if preferences.switch_position != 'LEFT':
        return

    if len(preferences.editor_groups) == 0:
        return

    found_switches = False
    for group in preferences.editor_groups:
        if not group.show_in_header:
            continue
        for editor in group.editors:
            if editor.editor_type != 'EMPTY' and is_area_matching_editor(context.area, editor.editor_type):
                found_switches = True
                break
        if found_switches:
            break

    if not found_switches:
        return

    layout = self.layout
    row = layout.row(align=True)

    box = row.box()
    switch_row = box.row(align=True)

    for group in preferences.editor_groups:
        if not group.show_in_header:
            continue
        for editor in group.editors:
            if editor.editor_type != 'EMPTY' and is_area_matching_editor(context.area, editor.editor_type):
                for e in group.editors:
                    name, icon = enum_name_and_icon(e.editor_type)
                    is_active = is_area_matching_editor(context.area, e.editor_type)
                    op = switch_row.operator("wm.switch_editor", text="", icon=icon, depress=is_active)
                    op.editor_type = e.editor_type

                if preferences.show_separator:
                    row.label(text="||")

                return

# Add the keyboard shortcut management

# Keep track of shortcuts
addon_keymaps = []

# Class List
classes = [
    EditorEntry,
    EditorGroup,
    OT_MoveEditorUp,
    OT_MoveEditorDown,
    VIEW3D_PT_QuickSwitchPreferences,
    EDITOR_UL_Groups,
    EDITOR_UL_Entries,
    OT_AddEditorGroup,
    OT_RemoveEditorGroup,
    OT_AddEditorToGroup,
    OT_RemoveEditorFromGroup,
    OT_SwitchEditor,
    OT_CycleEditors,
    OT_ExportConfig,
    OT_ImportConfig,
]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    # Register draw callbacks for available headers (4.2–4.5 compatible)
    header_names = [
        'NODE_HT_header', 'DOPESHEET_HT_header', 'PROPERTIES_HT_header',
        'OUTLINER_HT_header', 'SPREADSHEET_HT_header', 'IMAGE_HT_header',
        'VIEW3D_HT_header', 'PREFERENCES_HT_header', 'USERPREF_HT_header',
        'CONSOLE_HT_header', 'TEXT_HT_header', 'GRAPH_HT_header',
        'SEQUENCER_HT_header', 'CLIP_HT_header', 'NLA_HT_header',
        'INFO_HT_header', 'FILEBROWSER_HT_header',
    ]

    for name in header_names:
        header = getattr(bpy.types, name, None)
        if not header:
            continue
        try:
            header.prepend(draw_left_switches)
        except Exception:
            pass
        try:
            header.append(draw_tab_switcher_btn)
        except Exception:
            pass
        
    # Ensure context stability
    bpy.app.timers.register(load_and_register_deferred, first_interval=0.1)

def load_and_register_deferred():
    """Loading of config"""
    try:
        if __package__ in bpy.context.preferences.addons:
             load_config_from_json()
    except Exception:
        pass
        
    register_shortcuts()
    return None

# Add a function to register shortcuts
def register_shortcuts():
    """Avoid conflicts"""
    prefs = None
    try:
        if __package__ in bpy.context.preferences.addons:
            prefs = bpy.context.preferences.addons[__package__].preferences
    except Exception:
        return

    if not prefs or not prefs.use_shortcuts:
        return

    wm = bpy.context.window_manager
    kc = getattr(wm, 'keyconfigs', None)
    kc = getattr(kc, 'addon', None)
    if not kc:
        return

    # Common editor keymaps
    keymap_specs = []
    
    # Add global keymap first
    keymap_specs.append(("Window", 'EMPTY'))
    
    for key, data in EDITOR_DATA.items():
        # Only add if a keymap name is specified
        if data['keymap']:
            keymap_specs.append((data['keymap'], data['type']))

    # Build base kwargs from preferences
    base_kwargs = {
        "idname": "wm.cycle_editors",
        "type": prefs.cycle_shortcut_key,
        "value": 'PRESS',
    }
    if prefs.cycle_shortcut_modifier == 'CTRL':
        base_kwargs["ctrl"] = True
    elif prefs.cycle_shortcut_modifier == 'ALT':
        base_kwargs["alt"] = True
    elif prefs.cycle_shortcut_modifier == 'SHIFT':
        base_kwargs["shift"] = True
    elif prefs.cycle_shortcut_modifier == 'CTRL_ALT':
        base_kwargs["ctrl"] = True
        base_kwargs["alt"] = True
    elif prefs.cycle_shortcut_modifier == 'CTRL_SHIFT':
        base_kwargs["ctrl"] = True
        base_kwargs["shift"] = True
    elif prefs.cycle_shortcut_modifier == 'ALT_SHIFT':
        base_kwargs["alt"] = True
        base_kwargs["shift"] = True

    for name, space_type in keymap_specs:
        try:
            km = kc.keymaps.new(name=name, space_type=space_type, region_type='WINDOW')
            kmi = km.keymap_items.new(**base_kwargs)
            addon_keymaps.append((km, kmi))
        except Exception:
            # Skip missing/incompatible keymaps
            continue

def unregister():
    # Remove both draw functions from available headers
    header_names = [
        'NODE_HT_header', 'DOPESHEET_HT_header', 'PROPERTIES_HT_header',
        'OUTLINER_HT_header', 'SPREADSHEET_HT_header', 'IMAGE_HT_header',
        'VIEW3D_HT_header', 'PREFERENCES_HT_header', 'USERPREF_HT_header',
        'CONSOLE_HT_header', 'TEXT_HT_header', 'GRAPH_HT_header',
        'SEQUENCER_HT_header', 'CLIP_HT_header', 'NLA_HT_header',
        'INFO_HT_header', 'FILEBROWSER_HT_header',
    ]

    for name in header_names:
        header = getattr(bpy.types, name, None)
        if not header:
            continue
        try:
            header.remove(draw_tab_switcher_btn)
        except Exception:
            pass
        try:
            header.remove(draw_left_switches)
        except Exception:
            pass

    # Clean up keyboard shortcuts
    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __package__ == "__main__":
    register()
